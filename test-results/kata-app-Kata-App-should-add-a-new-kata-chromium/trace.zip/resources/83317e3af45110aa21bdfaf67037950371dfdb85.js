(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_d3d6be78._.js",
  "static/chunks/65a58_next_dist_compiled_react-dom_58873666._.js",
  "static/chunks/65a58_next_dist_compiled_next-devtools_index_25516d8b.js",
  "static/chunks/65a58_next_dist_compiled_fac0d096._.js",
  "static/chunks/65a58_next_dist_client_3861f5cc._.js",
  "static/chunks/65a58_next_dist_0d1d9489._.js",
  "static/chunks/69652_@swc_helpers_cjs_77b72907._.js"
],
    source: "entry"
});
